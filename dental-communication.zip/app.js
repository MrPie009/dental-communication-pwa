class DentalCommunicationApp {
    constructor() {
        // Application data
        this.responses = [
            {id: 1, text: "Yes", isDefault: true},
            {id: 2, text: "No", isDefault: true},
            {id: 3, text: "Stop", isDefault: false},
            {id: 4, text: "More pressure", isDefault: false},
            {id: 5, text: "Less pressure", isDefault: false},
            {id: 6, text: "I'm okay", isDefault: false}
        ];
        
        this.settings = {
            speechRate: 1.0,
            speechVolume: 1.0,
            speechPitch: 1.0
        };
        
        // State management
        this.currentSelection = 0;
        this.isAdminMode = false;
        this.gridColumns = 2;
        this.nextId = 7;
        
        // Initialize the app
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.renderResponses();
        this.updateResponseList();
        this.initializeSpeechControls();
        this.selectResponse(0);
        
        // Check for speech synthesis support
        if (!('speechSynthesis' in window)) {
            this.showStatus('Text-to-speech not supported in this browser', 'error');
        } else {
            this.showStatus('Text-to-speech ready. Use arrow keys to navigate, Enter to select.');
        }
    }
    
    bindEvents() {
        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeydown(e));
        
        // Admin toggle
        const adminToggle = document.getElementById('adminToggle');
        if (adminToggle) {
            adminToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleAdminMode();
            });
        }
        
        // Instructions toggle
        const instructionsToggle = document.getElementById('instructionsToggle');
        if (instructionsToggle) {
            instructionsToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleInstructions();
            });
        }
        
        // Volume test
        const volumeTest = document.getElementById('volumeTest');
        if (volumeTest) {
            volumeTest.addEventListener('click', (e) => {
                e.preventDefault();
                this.testVolume();
            });
        }
        
        // Admin panel controls
        const addResponse = document.getElementById('addResponse');
        if (addResponse) {
            addResponse.addEventListener('click', (e) => {
                e.preventDefault();
                this.addNewResponse();
            });
        }
        
        const newResponseText = document.getElementById('newResponseText');
        if (newResponseText) {
            newResponseText.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.addNewResponse();
                }
            });
        }
        
        const resetResponses = document.getElementById('resetResponses');
        if (resetResponses) {
            resetResponses.addEventListener('click', (e) => {
                e.preventDefault();
                this.resetToDefault();
            });
        }
        
        const exitAdmin = document.getElementById('exitAdmin');
        if (exitAdmin) {
            exitAdmin.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleAdminMode();
            });
        }
        
        // Speech controls
        const volumeSlider = document.getElementById('volumeSlider');
        if (volumeSlider) {
            volumeSlider.addEventListener('input', (e) => {
                this.updateVolume(e.target.value);
            });
        }
        
        const speedSlider = document.getElementById('speedSlider');
        if (speedSlider) {
            speedSlider.addEventListener('input', (e) => {
                this.updateSpeed(e.target.value);
            });
        }
    }
    
    handleKeydown(e) {
        // Prevent default behavior for navigation keys
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter', ' '].includes(e.key)) {
            e.preventDefault();
        }
        
        // Skip navigation if in admin mode and focused on input
        if (this.isAdminMode && e.target.tagName === 'INPUT') return;
        
        const totalResponses = this.responses.length;
        const currentRow = Math.floor(this.currentSelection / this.gridColumns);
        const currentCol = this.currentSelection % this.gridColumns;
        const totalRows = Math.ceil(totalResponses / this.gridColumns);
        
        switch (e.key) {
            case 'ArrowUp':
                if (currentRow > 0) {
                    const newSelection = (currentRow - 1) * this.gridColumns + currentCol;
                    this.selectResponse(Math.min(newSelection, totalResponses - 1));
                }
                break;
                
            case 'ArrowDown':
                if (currentRow < totalRows - 1) {
                    const newSelection = (currentRow + 1) * this.gridColumns + currentCol;
                    this.selectResponse(Math.min(newSelection, totalResponses - 1));
                }
                break;
                
            case 'ArrowLeft':
                if (this.currentSelection > 0) {
                    this.selectResponse(this.currentSelection - 1);
                }
                break;
                
            case 'ArrowRight':
                if (this.currentSelection < totalResponses - 1) {
                    this.selectResponse(this.currentSelection + 1);
                }
                break;
                
            case 'Enter':
            case ' ':
                this.activateResponse(this.currentSelection);
                break;
        }
    }
    
    selectResponse(index) {
        // Remove previous selection
        const prevButton = document.querySelector('.response-btn.selected');
        if (prevButton) {
            prevButton.classList.remove('selected');
        }
        
        // Update current selection
        this.currentSelection = Math.max(0, Math.min(index, this.responses.length - 1));
        
        // Add selection to new button
        const buttons = document.querySelectorAll('.response-btn');
        if (buttons[this.currentSelection]) {
            buttons[this.currentSelection].classList.add('selected');
            buttons[this.currentSelection].focus();
        }
        
        // Update status
        const selectedText = this.responses[this.currentSelection]?.text || '';
        this.showStatus(`Selected: ${selectedText}`);
    }
    
    activateResponse(index) {
        const response = this.responses[index];
        if (!response) return;
        
        // Visual feedback
        const button = document.querySelectorAll('.response-btn')[index];
        if (button) {
            button.classList.add('speaking');
            setTimeout(() => {
                button.classList.remove('speaking');
            }, 2000);
        }
        
        // Show immediate feedback
        this.showStatus(`Speaking: "${response.text}"`, 'success');
        
        // Speak the response
        this.speakText(response.text);
    }
    
    speakText(text) {
        if (!('speechSynthesis' in window)) {
            this.showStatus('Text-to-speech not available in this browser', 'error');
            return;
        }
        
        try {
            // Cancel any ongoing speech
            speechSynthesis.cancel();
            
            // Create and configure utterance
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = this.settings.speechRate;
            utterance.volume = this.settings.speechVolume;
            utterance.pitch = this.settings.speechPitch;
            
            // Add event listeners
            utterance.onstart = () => {
                console.log('Speech started:', text);
            };
            
            utterance.onend = () => {
                this.showStatus('Ready for next selection');
                console.log('Speech ended');
            };
            
            utterance.onerror = (e) => {
                this.showStatus('Speech error - please try again', 'error');
                console.error('Speech synthesis error:', e);
            };
            
            // Speak
            speechSynthesis.speak(utterance);
            
        } catch (error) {
            console.error('Speech error:', error);
            this.showStatus('Speech synthesis failed', 'error');
        }
    }
    
    renderResponses() {
        const grid = document.getElementById('responseGrid');
        if (!grid) return;
        
        grid.innerHTML = '';
        
        // Determine grid layout
        this.gridColumns = this.responses.length <= 2 ? 2 : Math.min(3, Math.ceil(Math.sqrt(this.responses.length)));
        grid.style.gridTemplateColumns = `repeat(${this.gridColumns}, 1fr)`;
        
        this.responses.forEach((response, index) => {
            const button = document.createElement('button');
            button.className = 'response-btn';
            button.textContent = response.text;
            button.setAttribute('data-index', index);
            button.setAttribute('data-id', response.id);
            button.type = 'button';
            
            // Add click handler
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.selectResponse(index);
                this.activateResponse(index);
            });
            
            grid.appendChild(button);
        });
        
        // Auto-select first response
        if (this.responses.length > 0) {
            setTimeout(() => {
                this.selectResponse(0);
            }, 100);
        }
    }
    
    toggleAdminMode() {
        this.isAdminMode = !this.isAdminMode;
        const adminPanel = document.getElementById('adminPanel');
        const adminToggle = document.getElementById('adminToggle');
        
        if (!adminPanel || !adminToggle) return;
        
        if (this.isAdminMode) {
            adminPanel.style.display = 'block';
            adminPanel.classList.remove('hidden');
            adminToggle.textContent = 'Exit Admin';
            adminToggle.classList.remove('btn--secondary');
            adminToggle.classList.add('btn--primary');
            this.updateResponseList();
            
            // Focus on input field
            setTimeout(() => {
                const input = document.getElementById('newResponseText');
                if (input) input.focus();
            }, 100);
            
            this.showStatus('Admin mode enabled - you can now customize responses');
        } else {
            adminPanel.style.display = 'none';
            adminPanel.classList.add('hidden');
            adminToggle.textContent = 'Admin Mode';
            adminToggle.classList.remove('btn--primary');
            adminToggle.classList.add('btn--secondary');
            this.showStatus('Admin mode disabled');
        }
    }
    
    toggleInstructions() {
        const panel = document.getElementById('instructionsPanel');
        if (!panel) return;
        
        const isHidden = panel.classList.contains('hidden') || panel.style.display === 'none';
        
        if (isHidden) {
            panel.style.display = 'block';
            panel.classList.remove('hidden');
            panel.classList.add('fade-in');
            this.showStatus('Instructions panel opened');
        } else {
            panel.style.display = 'none';
            panel.classList.add('hidden');
            this.showStatus('Instructions panel closed');
        }
    }
    
    testVolume() {
        this.showStatus('Testing volume...', 'info');
        this.speakText('Volume test. This is how loud the voice will be at the current settings.');
    }
    
    addNewResponse() {
        const input = document.getElementById('newResponseText');
        if (!input) return;
        
        const text = input.value.trim();
        
        if (!text) {
            this.showStatus('Please enter response text', 'error');
            input.focus();
            return;
        }
        
        if (this.responses.length >= 8) {
            this.showStatus('Maximum 8 responses allowed', 'error');
            return;
        }
        
        // Check for duplicates
        if (this.responses.find(r => r.text.toLowerCase() === text.toLowerCase())) {
            this.showStatus('Response already exists', 'error');
            input.focus();
            return;
        }
        
        // Add new response
        const newResponse = {
            id: this.nextId++,
            text: text,
            isDefault: false
        };
        
        this.responses.push(newResponse);
        input.value = '';
        
        // Update UI
        this.renderResponses();
        this.updateResponseList();
        this.showStatus(`Added: "${text}"`, 'success');
        input.focus();
    }
    
    deleteResponse(id) {
        const responseIndex = this.responses.findIndex(r => r.id === id);
        if (responseIndex === -1) return;
        
        const response = this.responses[responseIndex];
        
        // Don't allow deleting default responses
        if (response.isDefault) {
            this.showStatus('Cannot delete default responses', 'error');
            return;
        }
        
        // Remove response
        const removedText = response.text;
        this.responses.splice(responseIndex, 1);
        
        // Update current selection if needed
        if (this.currentSelection >= this.responses.length) {
            this.currentSelection = Math.max(0, this.responses.length - 1);
        }
        
        // Update UI
        this.renderResponses();
        this.updateResponseList();
        this.showStatus(`Deleted: "${removedText}"`, 'success');
    }
    
    editResponse(id, newText) {
        const response = this.responses.find(r => r.id === id);
        if (!response || response.isDefault) return;
        
        if (!newText.trim()) {
            this.showStatus('Response text cannot be empty', 'error');
            return;
        }
        
        // Check for duplicates (excluding current response)
        if (this.responses.find(r => r.id !== id && r.text.toLowerCase() === newText.toLowerCase())) {
            this.showStatus('Response already exists', 'error');
            return;
        }
        
        const oldText = response.text;
        response.text = newText.trim();
        
        // Update UI
        this.renderResponses();
        this.updateResponseList();
        this.showStatus(`Updated: "${oldText}" → "${newText}"`, 'success');
    }
    
    updateResponseList() {
        const responseList = document.getElementById('responseList');
        if (!responseList) return;
        
        responseList.innerHTML = '';
        
        this.responses.forEach(response => {
            const item = document.createElement('div');
            item.className = `response-item ${response.isDefault ? 'default' : ''}`;
            
            const textSpan = document.createElement('span');
            textSpan.className = 'response-text';
            textSpan.textContent = response.text;
            
            const actions = document.createElement('div');
            actions.className = 'response-actions';
            
            if (!response.isDefault) {
                // Edit button
                const editBtn = document.createElement('button');
                editBtn.className = 'btn btn--outline btn--sm';
                editBtn.textContent = 'Edit';
                editBtn.type = 'button';
                editBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const newText = prompt('Edit response:', response.text);
                    if (newText !== null) {
                        this.editResponse(response.id, newText);
                    }
                });
                actions.appendChild(editBtn);
                
                // Delete button
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'btn btn--outline btn--sm';
                deleteBtn.textContent = 'Delete';
                deleteBtn.type = 'button';
                deleteBtn.style.color = 'var(--color-error)';
                deleteBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (confirm(`Delete "${response.text}"?`)) {
                        this.deleteResponse(response.id);
                    }
                });
                actions.appendChild(deleteBtn);
            } else {
                const defaultLabel = document.createElement('span');
                defaultLabel.className = 'status status--success';
                defaultLabel.textContent = 'Default';
                actions.appendChild(defaultLabel);
            }
            
            item.appendChild(textSpan);
            item.appendChild(actions);
            responseList.appendChild(item);
        });
    }
    
    resetToDefault() {
        if (!confirm('Reset to default Yes/No responses? This will remove all custom responses.')) {
            return;
        }
        
        this.responses = [
            {id: 1, text: "Yes", isDefault: true},
            {id: 2, text: "No", isDefault: true}
        ];
        
        this.currentSelection = 0;
        this.renderResponses();
        this.updateResponseList();
        this.showStatus('Reset to default responses', 'success');
    }
    
    updateVolume(value) {
        this.settings.speechVolume = parseFloat(value);
        const display = document.getElementById('volumeDisplay');
        if (display) {
            display.textContent = `${Math.round(value * 100)}%`;
        }
    }
    
    updateSpeed(value) {
        this.settings.speechRate = parseFloat(value);
        const display = document.getElementById('speedDisplay');
        if (display) {
            display.textContent = `${value}x`;
        }
    }
    
    initializeSpeechControls() {
        // Initialize volume slider
        const volumeSlider = document.getElementById('volumeSlider');
        if (volumeSlider) {
            volumeSlider.value = this.settings.speechVolume;
            this.updateVolume(this.settings.speechVolume);
        }
        
        // Initialize speed slider
        const speedSlider = document.getElementById('speedSlider');
        if (speedSlider) {
            speedSlider.value = this.settings.speechRate;
            this.updateSpeed(this.settings.speechRate);
        }
    }
    
    showStatus(message, type = 'info') {
        const statusMessage = document.getElementById('statusMessage');
        if (!statusMessage) return;
        
        statusMessage.textContent = message;
        
        // Remove previous status classes
        statusMessage.className = '';
        
        // Add appropriate status class
        if (type === 'error') {
            statusMessage.style.color = 'var(--color-error)';
        } else if (type === 'success') {
            statusMessage.style.color = 'var(--color-success)';
        } else {
            statusMessage.style.color = 'var(--color-text-secondary)';
        }
        
        // Auto-clear error messages after 4 seconds
        if (type === 'error') {
            setTimeout(() => {
                if (statusMessage.textContent === message) {
                    this.showStatus('Use arrow keys to navigate, Enter to select');
                }
            }, 4000);
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Dental Communication App...');
    window.dentalApp = new DentalCommunicationApp();
    console.log('App initialized successfully');
});

// Handle visibility changes to pause speech when tab is not active
document.addEventListener('visibilitychange', () => {
    if (document.hidden && 'speechSynthesis' in window) {
        speechSynthesis.pause();
    } else if ('speechSynthesis' in window) {
        speechSynthesis.resume();
    }
});

// Prevent context menu on right-click to avoid interference with remote controls
document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
});

// Add global error handling
window.addEventListener('error', (e) => {
    console.error('Application error:', e.error);
    if (window.dentalApp) {
        window.dentalApp.showStatus('An error occurred. Please refresh the page.', 'error');
    }
});